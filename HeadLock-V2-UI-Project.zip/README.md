# HeadLock-V2 UI

Android UI demo with:
- Hidden password-style key entry
- Red/black menu
- Gray OFF / green ON switches
- Toast/status messages
- 3-second green BOST RAM visual overlay

The switches are UI-only and do not modify or interact with Free Fire.
