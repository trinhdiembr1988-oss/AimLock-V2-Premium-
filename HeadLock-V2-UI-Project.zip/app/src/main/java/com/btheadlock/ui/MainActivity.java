package com.btheadlock.ui;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.content.*;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final String VALID_KEY = "OB55XINCHAO-7777";
    private LinearLayout root, menu;
    private TextView status;
    private int RED = Color.rgb(245, 25, 32);
    private int GREEN = Color.rgb(0, 220, 105);
    private int GRAY = Color.rgb(70, 70, 74);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        showKeyGate();
    }

    private GradientDrawable bg(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private TextView text(String s, float size) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextColor(Color.WHITE);
        t.setTextSize(size);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private void showKeyGate() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER);
        box.setPadding(48, 40, 48, 40);
        box.setBackgroundColor(Color.rgb(5,5,5));

        TextView title = text("HEADLOCK", 30);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, 1);
        box.addView(title, new LinearLayout.LayoutParams(-1, 80));

        TextView sub = text("🔐  NHẬP KEY ĐỂ TIẾP TỤC", 16);
        sub.setGravity(Gravity.CENTER);
        box.addView(sub, new LinearLayout.LayoutParams(-1, 55));

        EditText key = new EditText(this);
        key.setHint("Nhập key");
        key.setHintTextColor(Color.GRAY);
        key.setTextColor(Color.WHITE);
        key.setSingleLine(true);
        key.setInputType(0x00000081); // password
        key.setPadding(28, 0, 28, 0);
        key.setBackground(bg(Color.rgb(28,28,30), 28));
        box.addView(key, new LinearLayout.LayoutParams(-1, 62));

        Button enter = new Button(this);
        enter.setText("XÁC NHẬN");
        enter.setTextColor(Color.WHITE);
        enter.setTextSize(15);
        enter.setBackground(bg(RED, 28));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(-1, 62);
        ep.topMargin = 22;
        box.addView(enter, ep);

        TextView err = text("", 14);
        err.setGravity(Gravity.CENTER);
        box.addView(err, new LinearLayout.LayoutParams(-1, 55));

        enter.setOnClickListener(v -> {
            if (VALID_KEY.equals(key.getText().toString().trim())) {
                ((android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE))
                        .hideSoftInputFromWindow(key.getWindowToken(), 0);
                showMenu();
            } else {
                err.setText("Key không hợp lệ");
                err.setTextColor(RED);
            }
        });

        setContentView(box);
    }

    private void showMenu() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(18, 18, 18, 28);
        root.setBackgroundColor(Color.rgb(5,5,5));
        scroll.addView(root);

        TextView head = text("HEADLOCK", 27);
        head.setGravity(Gravity.CENTER);
        head.setTypeface(null, 1);
        root.addView(head, new LinearLayout.LayoutParams(-1, 70));

        TextView sub = text("MENU • UI DEMO", 13);
        sub.setGravity(Gravity.CENTER);
        sub.setTextColor(Color.LTGRAY);
        root.addView(sub, new LinearLayout.LayoutParams(-1, 38));

        menu = new LinearLayout(this);
        menu.setOrientation(LinearLayout.VERTICAL);
        menu.setPadding(18, 18, 18, 18);
        menu.setBackground(bg(Color.rgb(24,24,26), 32));
        root.addView(menu, new LinearLayout.LayoutParams(-1, -2));

        addSwitch("🎯  REG FILES", false, false);
        addSwitch("🚀  BOST RAM", false, true);
        addSwitch("💀  HEADLOCK", false, false);
        addSwitch("⚙️  FIX RUNG", false, false);
        addSwitch("♾️  VÔ GAME", false, false);
        addSwitch("📳  RUNG TÂM", false, false);

        status = text("Sẵn sàng", 14);
        status.setGravity(Gravity.CENTER);
        status.setTextColor(Color.LTGRAY);
        root.addView(status, new LinearLayout.LayoutParams(-1, 55));

        setContentView(scroll);
    }

    private void addSwitch(String label, boolean initial, boolean boostDemo) {
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(8, 8, 8, 8);

        TextView name = text(label, 17);
        row.addView(name, new LinearLayout.LayoutParams(0, 68, 1));

        Switch sw = new Switch(this);
        sw.setChecked(initial);
        sw.setShowText(false);
        sw.setTextOn("");
        sw.setTextOff("");
        row.addView(sw, new LinearLayout.LayoutParams(60, 60));

        menu.addView(row);

        sw.setOnCheckedChangeListener((button, checked) -> {
            sw.getThumbDrawable().setTint(Color.WHITE);
            sw.getTrackDrawable().setTint(checked ? GREEN : GRAY);
            String clean = label.replaceAll("^[^ ]+\\s+", "");
            status.setText((checked ? "Đã bật " : "Đã tắt ") + clean);
            status.setTextColor(checked ? GREEN : Color.LTGRAY);

            if (checked && boostDemo) showBoostOverlay();
        });
        sw.getThumbDrawable().setTint(Color.WHITE);
        sw.getTrackDrawable().setTint(initial ? GREEN : GRAY);
    }

    private void showBoostOverlay() {
        final PopupWindow popup = new PopupWindow(this);
        TextView square = text("FPS\nBOOST", 11);
        square.setGravity(Gravity.CENTER);
        square.setTextColor(Color.WHITE);
        square.setBackground(bg(Color.rgb(0, 150, 75), 16));
        popup.setContentView(square);
        popup.setWidth(92);
        popup.setHeight(92);
        popup.setBackgroundDrawable(bg(Color.rgb(0, 150, 75), 16));
        popup.setOutsideTouchable(false);
        popup.setFocusable(false);
        popup.showAtLocation(root, Gravity.CENTER, 0, 0);
        new Handler().postDelayed(popup::dismiss, 3000);
    }
}
